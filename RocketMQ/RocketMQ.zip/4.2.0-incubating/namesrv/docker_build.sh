#!/bin/bash

sudo docker build -t sjfx/rocketmq-namesrv:4.2.0 .
