#!/bin/bash
sudo docker run -d -p 9876:9876 --name rmqnamesrv  sjfx/rocketmq-namesrv:4.2.0
