#!/bin/bash

sudo docker build -t sjfx/rocketmq-broker:4.2.0 .
